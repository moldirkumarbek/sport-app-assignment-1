package us.reachmobi.sportapp.data.enums

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}