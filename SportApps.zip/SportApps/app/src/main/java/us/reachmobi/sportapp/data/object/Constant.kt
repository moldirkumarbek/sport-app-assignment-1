package us.reachmobi.sportapp.data.`object`

object Constant {
    const val OkHttp_TIMEOUT = 5L // connection timeout
}