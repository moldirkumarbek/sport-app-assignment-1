package us.reachmobi.sportapp.data.remote.response

data class ErrorResponseBody (
    val status: String?,
    val code: String?,
    val message: String?
    )