package us.reachmobi.sportapp.util

const val HIDE_KEYBOARD = 900
const val ERROR = 901
const val LOADING = 902