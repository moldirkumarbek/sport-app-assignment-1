package us.reachmobi.sportapp.di

import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

val roomModule = module {
//    single {
//        SportAppDatabase(androidApplication())
//    }
//    single(createdAtStart = false) { get<SportAppDatabase>().schoolDao() }
//    single(createdAtStart = false) { get<SportAppDatabase>().scoreDao() }
}