package us.reachmobi.sportapp.data.remote.response

import us.reachmobi.sportapp.data.model.Team

data class Teams(
    val teams: List<Team>? = listOf()
)