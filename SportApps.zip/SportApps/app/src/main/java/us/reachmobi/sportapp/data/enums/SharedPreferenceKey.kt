package us.reachmobi.sportapp.data.enums

enum class SharedPreferenceKey {
    ACCESS_TOKEN
}